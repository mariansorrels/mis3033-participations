﻿namespace FirstWPFApplication
{
    internal class txbAge
    {
    }
}